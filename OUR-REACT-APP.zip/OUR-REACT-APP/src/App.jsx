import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <a href="EDUBE_AI_PROFILE.jpg" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>GROUP WORK</h1>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          TRY THIS {count}
        </button>
        <p>
          The  <code>best/App ever</code> and we are growing bigger
        </p>
      </div>
      <p className="read-the-docs">
        we welcome you to our first app by
        edube, Musiguzi, Towet, Joesline,Emma,Junior,George,Ricky, Rojus.

      </p>
    </>
  )
}

export default App
